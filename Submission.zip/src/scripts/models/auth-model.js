export default class AuthModel {
  static async register(name, email, password) {
    try {
      const response = await fetch('https://story-api.dicoding.dev/v1/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password })
      });
      return await response.json();
    } catch (error) {
      throw new Error('Error while registering: ' + error.message);
    }
  }
  
  static async login(email, password) {
    try {
      const response = await fetch('https://story-api.dicoding.dev/v1/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      return await response.json();
    } catch (error) {
      throw new Error('Error while logging in: ' + error.message);
    }
  }
}