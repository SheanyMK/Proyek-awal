import AboutView from "./about-view";
import AboutPresenter from "./about-presenter";

export default class AboutPage {
  async render() {
    return `
      <section class="container">
        <h1>Tentang Story App</h1>
        <div id="about-content"></div>
      </section>
    `;
  }

  async afterRender() {
    const view = new AboutView();
    new AboutPresenter(view);
  }
}