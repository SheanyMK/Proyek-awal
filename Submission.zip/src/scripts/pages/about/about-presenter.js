import NavManager from "../../utils/nav-manager";

export default class AboutPresenter {
  constructor(view) {
    this.view = view;
    this.navManager = new NavManager();
    this.init();
  }

  async init() {
    this.navManager.updateNavigation();
    const token = localStorage.getItem("accessToken");
    if (!token) {
      this.view.showMessage("Silakan login terlebih dahulu.");
      this.redirectToLogin();
      return;
    }
    try {
      await this.view.showAboutContent();
    } catch (error) {
      this.view.showMessage(error.message);
    }
  }

  redirectToLogin() {
    localStorage.setItem("redirectAfterLogin", window.location.pathname);
    setTimeout(() => {
      window.location.href = "#/login";
    }, 1);
  }
}