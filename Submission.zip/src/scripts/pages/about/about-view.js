export default class AboutView {
  constructor() {
    this._aboutContent = document.getElementById('about-content');
  }

  async showAboutContent() {
    if (document.startViewTransition) {
      await document.startViewTransition(() => this._renderAboutContent());
    } else {
      this._renderAboutContent();
    }
  }

  _renderAboutContent() {
    this._aboutContent.innerHTML = `
      <p class="intro">
        Story App adalah platform berbagi cerita berbasis lokasi, memungkinkan pengguna mengeksplorasi dan membagikan momen spesial dari seluruh Indonesia. Dibangun dengan API Dicoding, kami menyajikan pengalaman interaktif melalui peta digital dan cerita yang hidup.
      </p>
      <br> 
      
      <div class="features">
        <h2>Fitur Utama</h2>
        <ul>
          <li>Peta Interaktif : Telusuri cerita dari berbagai daerah dengan marker di peta. Klik marker untuk melihat detail cerita (foto + deskripsi).</li>
          <li>Mudah digunakan : Tambah cerita dalam 3 langkah: foto, deskripsi, dan lokasi. Antarmuka responsif (desktop & mobile).</li>
          <li>Terjamin keamanannya : Sistem login/register dengan token autentikasi. Data tersimpan aman di cloud API Dicoding.</li>
        </ul>
      </div>
      <br>
      
      <div class="team">
        <h2>Tim Pengembang</h2>
        <ul>
          <li> Backend: Story API Dicoding (https://story-api.dicoding.dev/v1). Penyimpanan gambar terenkripsi
          </li>
          <li>Frontend: Single Page Application (SPA) dengan JavaScript modern. Peta digital: Leaflet.js + OpenStreetMap . Animasi: View Transition API</li>
        </ul>
      </div>
      <br>

      <div class="contact">
        <h2>Hubungi Kami</h2>
        <p>Email: dev@storyaap.id</p>
        <p>Instagram: <a href="https://instagram.com/storyapp" target="_blank">@storyapp</a></p>
      </div>
    `;

    // Tambahkan animasi seperti pada home-view
    const elements = this._aboutContent.querySelectorAll('div, p');
    elements.forEach((element, index) => {
      element.animate([
        { opacity: 0, transform: 'translateY(20px)' },
        { opacity: 1, transform: 'translateY(0)' }
      ], {
        duration: 400,
        delay: index * 100, // menambahkan delay untuk efek bertahap
        easing: 'ease-out'
      });
    });
  }

  showMessage(msg) {
    this._aboutContent.innerHTML = `<p style="color:red;">${msg}</p>`;
  }
}