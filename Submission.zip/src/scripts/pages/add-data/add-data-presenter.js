import NavManager from "../../utils/nav-manager.js";
import StoryModel from "./../../models/story-model.js";

export default class AddDataPresenter {
  constructor(view) {
    this.view = view;
    this.mediaStream = null;
    this.selectedLocation = null;
    this.marker = null;
    this.capturedBlob = null;
    this.navManager = new NavManager();
    this.init();
  }

  async init() {
    this.navManager.updateNavigation();
    const token = localStorage.getItem("accessToken");
    if (!token) {
      this.view.showMessage(
        '<p style="color:red;">Silakan login terlebih dahulu.</p>'
      );
      this.redirectToLogin();
      return;
    }

    this.view.initMap(this.handleMapClick.bind(this));
    await this.initCamera();
    this.view.bindCaptureHandler(this.handleCapture.bind(this));
    this.view.bindSubmitHandler(this.handleSubmit.bind(this));
  }

  async initCamera() {
    try {
      this.mediaStream = await navigator.mediaDevices.getUserMedia({
        video: true,
      });
      this.view.video.srcObject = this.mediaStream;
    } catch (err) {
      console.error("Camera error:", err);
    }
  }

  stopCamera() {
    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach((track) => track.stop());
      this.view.video.srcObject = null;
      this.mediaStream = null;
      console.log("Camera has been stopped");
    }
  }

  handleCapture() {
    this.view.drawImageToCanvas();
    this.stopCamera();
    this.view.getCanvasBlob((blob) => {
      this.capturedBlob = blob;
    });
  }

  handleMapClick(coords) {
    this.selectedLocation = coords;
  }


  async handleSubmit(e) {
    e.preventDefault();

    const description = this.view.description;
    const image = this.view.uploadedFile || this.capturedBlob;
    const location = this.selectedLocation;

    if (!description) {
      this.view.showErrorMessage("Deskripsi harus diisi.");
      return;
    }
    if (!image) {
      this.view.showErrorMessage("Gambar harus diunggah atau diambil dari kamera.");
      return;
    }
    if (!location) {
      this.view.showErrorMessage("Silakan pilih lokasi pada peta.");
      return;
    }

    try {
      await StoryModel.postStory(description, image, location.lat, location.lng);

      this.view.showSuccessMessage("Data berhasil ditambahkan!");
      this.view.resetForm();
      this.selectedLocation = null;
      this.view.removeMarker();
      this.capturedBlob = null;
      await this.initCamera();
    } catch (error) {
      console.error("Error:", error);
      this.view.showErrorMessage(`Terjadi kesalahan: ${error.message}`);
    }
  }

  redirectToLogin() {
    localStorage.setItem("redirectAfterLogin", window.location.pathname);
    this.view.goToLoginPage();
  }
}