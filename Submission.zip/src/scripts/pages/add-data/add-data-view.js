export default class AddDataView {
    constructor() {
        this.form = document.getElementById('add-data-form');
        this.messageEl = document.getElementById('add-message');
        this.video = document.getElementById('video');
        this.canvas = document.getElementById('canvas');
        this.captureBtn = document.getElementById('capture-btn');
        this.imageInput = document.getElementById('image');
    }
  
    get description() {
        return document.getElementById('description').value;
    }
  
    get uploadedFile() {
        return this.imageInput.files[0];
    }
  
    showMessage(html) {
        this.messageEl.innerHTML = html;
        setTimeout(() => {
            this.messageEl.innerHTML = '';
        }, 3000);
    }

    showErrorMessage(message) {
        this.showMessage(`<p style="color:red;">${message}</p>`);
    }

    showSuccessMessage(message) {
        this.showMessage(`<p style="color:green;">${message}</p>`);
    }
  
    drawImageToCanvas() {
        const ctx = this.canvas.getContext('2d');
        ctx.drawImage(this.video, 0, 0, this.canvas.width, this.canvas.height);
        this.canvas.style.display = 'block';
        this.video.style.display = 'none';
    }
  
    getCanvasBlob(callback) {
        this.canvas.toBlob(callback, 'image/jpeg');
    }
  
    resetForm() {
        this.form.reset();
        const ctx = this.canvas.getContext('2d');
        ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        this.canvas.style.display = 'none';
        this.video.style.display = 'block';
    }
  
    bindCaptureHandler(handler) {
        this.captureBtn.addEventListener('click', handler);
    }
  
    bindSubmitHandler(handler) {
        this.form.addEventListener('submit', handler);
    }

    goToLoginPage() {
        window.location.hash = "/login";
    }
    
    initMap(onMapClick) {
        const map = L.map("map").setView([-6.2088, 106.8456], 13);

        L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: "© OpenStreetMap contributors",
        }).addTo(map);

        this.map = map;

        map.on("click", (e) => {
        const lat = e.latlng.lat;
        const lng = e.latlng.lng;
        onMapClick({ lat, lng });
        this._addOrUpdateMarker(lat, lng);
        });
    }

    _addOrUpdateMarker(lat, lng) {
        if (this.marker) {
        this.map.removeLayer(this.marker);
        }
        this.marker = L.marker([lat, lng]).addTo(this.map);
    }

    removeMarker() {
        if (this.marker) {
        this.map.removeLayer(this.marker);
        this.marker = null;
        }
    }
}
  