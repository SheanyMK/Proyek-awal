import AddDataView from "./add-data-view";
import AddDataPresenter from "./add-data-presenter";

export default class AddDataPage {
  constructor() {
    this.mediaStream = null;
    this.selectedLocation = null;
    this.marker = null;
    this.presenter = null;
  }

  async render() {
    return `
      <section class="add-data-container">
        <div class="form-container">
          <h1>Tambah Data Baru</h1>
          
          <form id="add-data-form" class="add-data-form">
            <!-- Deskripsi -->
            <div class="form-group">
              <label for="description">Deskripsi:</label>
              <textarea id="description" placeholder="Masukkan deskripsi cerita" required></textarea>
            </div>

            <!-- Input gambar untuk mobile -->
            <div class="form-group">
              <label for="image">Ambil Gambar (Mobile):</label>
              <input type="file" id="image" accept="image/*" capture="environment">
            </div>

            <!-- Kamera untuk desktop -->
            <div id="camera-section" class="camera-section">
              <video id="video" width="300" autoplay playsinline></video>
              <button type="button" id="capture-btn" class="btn-capture">Ambil Gambar dari Kamera</button>
              <canvas id="canvas" width="300" height="225" style="display:none;"></canvas>
            </div>

            <!-- Peta -->
            <div id="map" class="map-container"></div>

            <!-- Tombol Submit -->
            <br>
            <button type="submit" class="btn-submit">Tambah Data</button>
          </form>

          <div id="add-message" class="message"></div>
        </div>
      </section>
    `;
  }

  async afterRender() {
    const view = new AddDataView();
    this.presenter = new AddDataPresenter(view);

    this._setupPageLeaveDetection();
  }

  _setupPageLeaveDetection() {
    window.addEventListener("hashchange", () => {
      if (this.presenter) {
        this.presenter.stopCamera();
        console.log("Camera stopped due to page navigation");
      }
    });

    window.addEventListener("beforeunload", () => {
      if (this.presenter) {
        this.presenter.stopCamera();
        console.log("Camera stopped due to page unload");
      }
    });
  }
}
