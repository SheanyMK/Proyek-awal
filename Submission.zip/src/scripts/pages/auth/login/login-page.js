import LoginPresenter from './login-presenter';
import LoginView from './login-view';
import * as StoryAPI from '../../../data/api';
import * as AuthModel from '../../../utils/auth';

export default class LoginPage {
  async render() {
    const view = new LoginView();
    return view.getTemplate();
  }

  async afterRender() {
    const view = new LoginView();
    const presenter = new LoginPresenter({
      view,
      model:StoryAPI,
      authModel: AuthModel,
    });

    view.bindSubmit((data) => presenter.handleLogin(data));
  }
}