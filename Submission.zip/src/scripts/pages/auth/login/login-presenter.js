import NavManager from "../../../utils/nav-manager";

export default class LoginPresenter {
  #view;
  #model;
  #authModel;

  constructor({ view, model, authModel }) {
    this.#view = view;
    this.#model = model;
    this.#authModel = authModel;
    this.navManager = new NavManager();
    this.init();
  }

  async init() {
    this.navManager.updateNavigation();
    const token = localStorage.getItem("accessToken");
    if (token) {
      this.redirectToLogin();
      return;
    }
  }

  async handleLogin({ email, password }) {
    this.#view.showSubmitLoadingButton();
    try {
      const response = await this.#model.getLogin({ email, password });
      if (!response.ok) {
        this.navManager.updateNavigation();
        this.#view.showError(response.message);
        return;
      }
      
      localStorage.setItem('accessToken', response.loginResult.token);
      this.#authModel.putAccessToken(response.loginResult.token);
      this.#view.showSuccess(response.message);
    } catch (error) {
      this.#view.showError(error.message);
    } finally {
      this.#view.hideSubmitLoadingButton();
    }
  }

  redirectToLogin() {
    localStorage.setItem("redirectAfterLogin", window.location.pathname);
    setTimeout(() => {
      window.location.href = "#/";
    }, 1);
  }
}
