export default class LoginView {
  constructor() {
    this.form = null;
    this.submitButtonContainer = null;
  }

  getTemplate() {
    return `
      <section class="login-container">
        <div class="login-box">
          <article class="login-form-container">
            <h1 class="login__title">Masuk ke Akun Anda</h1>
            <form id="login-form" class="login-form">
              <div class="form-group">
                <label for="email-input" class="login-form__email-title">Email</label>
                <div class="login-form__title-container">
                  <input id="email-input" type="email" name="email" placeholder="Contoh: nama@email.com">
                </div>
              </div>
              <div class="form-group">
                <label for="password-input" class="login-form__password-title">Kata Sandi</label>
                <div class="login-form__title-container">
                  <input id="password-input" type="password" name="password" placeholder="••••••••">
                </div>
              </div>
              <div class="form-buttons login-form__form-buttons">
                <div id="submit-button-container">
                  <button type="submit" class="btn-submit">Masuk</button>
                </div>
                <br>
                <p class="login-form__do-not-have-account">Belum punya akun? <a href="#/register">Daftar</a></p>
              </div>
            </form>
          </article>
        </div>
      </section>
    `;
  }

  bindSubmit(handler) {
    this.form = document.getElementById('login-form');
    this.submitButtonContainer = document.getElementById('submit-button-container');

    this.form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = document.getElementById('email-input').value;
      const password = document.getElementById('password-input').value;
      handler({ email, password });
    });
  }

  showSubmitLoadingButton() {
    this.submitButtonContainer.innerHTML = `
      <button type="submit" class="btn-submit" disabled> 
        <i class="fas fa-spinner loader-button"></i>...
      </button>
    `;
  }

  hideSubmitLoadingButton() {
    this.submitButtonContainer.innerHTML = `
      <button type="submit" class="btn-submit">Masuk</button>
    `;
  }

  showSuccess(message) {
    console.log(message);
    location.hash = '/';
  }

  showError(message) {
    alert(message);
  }
}
