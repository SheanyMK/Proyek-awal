import LogoutPresenter from './logout-presenter';
import LogoutView from './logout-view';
import * as AuthModel from '../../../utils/auth';

export default class LogoutPage {
  async render() {
    const view = new LogoutView();
    return view.getTemplate();
  }

  async afterRender() {
    const view = new LogoutView();
    const presenter = new LogoutPresenter({
      view,
      authModel: AuthModel,
    });

    presenter.handleLogout();
  }
}