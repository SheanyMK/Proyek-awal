import NavManager from "../../../utils/nav-manager";

export default class LogoutPresenter {
  #view;
  #authModel;

  constructor({ view, authModel }) {
    this.#view = view;
    this.navManager = new NavManager();
    this.#authModel = authModel;
  }

  async handleLogout() {
    try {
      this.#view.showLoading();
      this.#authModel.removeAccessToken();
      this.#view.showSuccess('Anda berhasil logout');
      this.navManager.updateNavigation();
      setTimeout(() => {
        location.hash = '/login';
      }, 1);
    } catch (error) {
      this.#view.showError(error.message);
    } 
  }
}