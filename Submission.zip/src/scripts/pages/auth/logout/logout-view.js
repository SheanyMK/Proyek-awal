export default class LogoutView {
  constructor() {
    this.container = null;
  }

  getTemplate() {
    return `
      <section class="logout-container">
        <div class="logout-box">
          <div id="logout-content" class="logout-content">
            <h2>Memproses Logout...</h2>
            <div class="loader"></div>
          </div>
        </div>
      </section>
    `;
  }

  showLoading() {
    this.container = document.getElementById("logout-content");
    this.container.innerHTML = `
      <h2>Memproses Logout...</h2>
      <div class="loader"></div>
    `;
  }

  hideLoading() {
    if (this.container) {
      this.container.querySelector(".loader").style.display = "none";
    }
  }

  showSuccess(message) {
    if (this.container) {
      this.container.innerHTML = `
        <div class="success-message">
          <i class="fas fa-check-circle"></i>
          <h2>${message}</h2>
          <p>Mengalihkan ke halaman login...</p>
        </div>
      `;
    }

    // Tambahkan juga notifikasi toast
    this._showToast(message, "success");
  }

  showError(message) {
    if (this.container) {
      this.container.innerHTML = `
        <div class="error-message">
          <i class="fas fa-exclamation-circle"></i>
          <h2>Gagal Logout</h2>
          <p>${message}</p>
          <a href="#/" class="btn">Kembali ke Beranda</a>
        </div>
      `;
    }

    // Tambahkan juga notifikasi toast
    this._showToast(`Gagal logout: ${message}`, "error");
  }

  _showToast(message, type = "success") {
    // Buat elemen toast
    const toast = document.createElement("div");
    toast.classList.add("toast", `toast-${type}`);
    toast.innerHTML = `
      <div class="toast-content">
        <i class="fas fa-${
          type === "success" ? "check-circle" : "exclamation-circle"
        }"></i>
        <span>${message}</span>
      </div>
    `;

    // Tambahkan ke body
    document.body.appendChild(toast);

    // Animasi masuk
    setTimeout(() => {
      toast.classList.add("show");
    }, 100);

    // Hapus toast setelah beberapa detik
    setTimeout(() => {
      toast.classList.remove("show");
      setTimeout(() => {
        document.body.removeChild(toast);
      }, 500);
    }, 3000);
  }
}
