import RegisterPresenter from './register-presenter';
import RegisterView from './register-view';
import * as StoryAPI from '../../../data/api';

export default class RegisterPage {
  async render() {
    const view = new RegisterView();
    return view.getTemplate();
  }

  async afterRender() {
    const view = new RegisterView();
    const presenter = new RegisterPresenter({
      view,
      model: StoryAPI,
    });

    view.bindSubmit((data) => presenter.handleRegister(data));
  }
}
