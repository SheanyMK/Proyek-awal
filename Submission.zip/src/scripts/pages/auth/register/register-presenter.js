import NavManager from "../../../utils/nav-manager";

export default class RegisterPresenter {
  #view;
  #model;

  constructor({ view, model }) {
    this.#view = view;
    this.#model = model;
    this.navManager = new NavManager();
    this.init();
  }

  async init() {
    this.navManager.updateNavigation();
    const token = localStorage.getItem("accessToken");
    if (token) {
      this.redirectToLogin();
      return;
    }
  }

  async handleRegister({ name, email, password }) {
    this.#view.showSubmitLoadingButton();
    try {
      const response = await this.#model.getRegistered({ name, email, password });

      if (!response.ok) {
        this.#view.showError(response.message);
        return;
      }

      this.#view.showSuccess(response.message);
    } catch (error) {
      this.#view.showError(error.message);
    } finally {
      this.#view.hideSubmitLoadingButton();
    }
  }

  redirectToLogin() {
    localStorage.setItem("redirectAfterLogin", window.location.pathname);
    setTimeout(() => {
      window.location.href = "#/";
    }, 1);
  }
}
