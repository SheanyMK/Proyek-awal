import HomeView from "./home-view";
import HomePresenter from "./home-presenter";
import Map from '../../utils/map';

export default class HomePage {
  #map = null;

  async render() {
    return `
      <section class="container">
        <h1>Home Page</h1>
        <div id="story-list"></div>
        <h2>Peta Lokasi</h2>
        <div id="map" style="height: 400px;"></div>
      </section>
    `;
  }

  async initialMap() {
    this.#map = await Map.build('#map', {
      zoom: 10,
      locate: true,
    });
  }

  setMap(mapInstance) {
    this._map = mapInstance;
  }

  async afterRender() {
    const view = new HomeView();
    new HomePresenter(view);
  }
}
