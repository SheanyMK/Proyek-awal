import L from "leaflet";
import Map from "../../utils/map"; // Tambahkan import ini

import markerIcon2x from "leaflet/dist/images/marker-icon-2x.png";
import markerIcon from "leaflet/dist/images/marker-icon.png";
import markerShadow from "leaflet/dist/images/marker-shadow.png";
import { showFormattedDate } from "./../../utils/index";

delete L.Icon.Default.prototype._getIconUrl;

L.Icon.Default.mergeOptions({
  iconRetinaUrl: markerIcon2x,
  iconUrl: markerIcon,
  shadowUrl: markerShadow,
});

export default class HomeView {
  constructor() {
    this._storyList = document.getElementById("story-list");
    this._mapContainer = document.getElementById("map");
  }

  async showStories(stories) {
    if (document.startViewTransition) {
      await document.startViewTransition(() => this._renderStories(stories));
    } else {
      this._renderStories(stories);
    }
  }

  _renderStories(stories) {
    this._storyList.innerHTML = "";

    this._mapContainer.innerHTML = "";

    setTimeout(() => {
      this._map = L.map(this._mapContainer).setView([-6.2, 106.8], 5);
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: "© OpenStreetMap contributors",
      }).addTo(this._map);

      // Loop story
      stories.forEach(async (story) => {
        const item = document.createElement("div");
        let locationName = "Lokasi tidak tersedia";
        if (story.lat && story.lon) {
          try {
            locationName = await Map.getPlaceNameByCoordinate(
              story.lat,
              story.lon
            );
          } catch (error) {
            console.error("Gagal mendapatkan nama lokasi:", error);
            locationName = `${story.lat}, ${story.lon}`;
          }
        }

        item.classList.add("story-item");
        item.innerHTML = `
          <img style="width: 300px; height: 300px;" class="story-img" src="${
            story.photoUrl
          }" alt="${story.name}">
          <h3>${story.name}</h3>
          <p>${story.description}</p>

          <div class="story-meta2">
            <div class="story-date">
              <i class="fas fa-calendar-alt"></i>
              ${showFormattedDate(new Date(story.createdAt).toLocaleDateString())}
            </div>
            <br>
            ${story.lat && story.lon ? `
            <div class="story-location">
              <i class="fas fa-map-marker-alt"></i>
              ${locationName}
            </div>
            ` : ''}
          </div>
          <div class="story-actions">
            <a href="/#/detail/${story.id}" class="btn-back">
              Detail
            </a>
          </div>
          <br><br>
        `;
        this._storyList.appendChild(item);

        if (story.lat && story.lon) {
          const marker = L.marker([story.lat, story.lon]).addTo(this._map);
          marker.bindPopup(
            `<strong>${story.name}</strong><br>${story.description}`
          );
        }

        item.animate(
          [
            { opacity: 0, transform: "translateY(20px)" },
            { opacity: 1, transform: "translateY(0)" },
          ],
          { duration: 400, easing: "ease-out" }
        );
      });
    }, 0);
  }

  setMap(mapInstance) {
    this._map = mapInstance;
  }

  async showMapWithMarkers(stories) {
    if (document.startViewTransition) {
      await document.startViewTransition(() => this._renderMap(stories));
    } else {
      this._renderMap(stories);
    }
  }

  _renderMap(stories) {
    if (this._map) {
      this._map.remove(); // Penting!
      this._map = null;
    }

    this._mapContainer.innerHTML = "";
    const map = L.map(this._mapContainer).setView([-6.2, 106.8], 5);

    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: "© OpenStreetMap contributors",
    }).addTo(map);

    stories.forEach((story) => {
      if (story.lat && story.lon) {
        const marker = L.marker([story.lat, story.lon]).addTo(map);
        marker.bindPopup(
          `<strong>${story.name}</strong><br>${story.description}`
        );
      }
    });
    this._map = map;
  }

  showMessage(msg) {
    this._storyList.innerHTML = `<p style="color:red;">${msg}</p>`;
  }
}
