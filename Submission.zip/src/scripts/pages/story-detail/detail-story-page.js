import DetailView from "./detail-story-view";
import DetailPresenter from "./detail-story-presenter";
import StoryModel from "../../models/story-model";

export default class DetailStoryPage {
  async render() {
    return `
      <section class="container">
        <h1>Detail Story</h1>
        <div id="detail-container"></div>
        <br><br>
        <h1>Peta Lokasi</h1>
        <div id="map" style="height: 400px;"></div>
      </section>
    `;
  }

  async afterRender() {
    const urlParams = new URLSearchParams(window.location.hash.split('?')[1]);
    const storyId = window.location.hash.split('/')[2] || urlParams.get('id');
    
    if (!storyId) {
      window.location.href = '#/';
      return;
    }

    const view = new DetailView();
    new DetailPresenter(view, storyId);
  }
}