import StoryModel from "../../models/story-model";
import NavManager from "../../utils/nav-manager";

export default class DetailPresenter {
  constructor(view, storyId) {
    this.view = view;
    this.storyId = storyId;
    this.navManager = new NavManager();
    this.init();
  }

  async init() {
    this.navManager.updateNavigation();
    const token = localStorage.getItem("accessToken");
    
    if (!token) {
      this.view.showMessage("Silakan login terlebih dahulu.");
      this.redirectToLogin();
      return;
    }

    try {
      const story = await StoryModel.getStoriesDetail(token, this.storyId);
      this.view.showStoryDetail(story);
      this.view.showMapWithMarker(story);
    } catch (error) {
      this.view.showMessage(error.message);
    }
  }

  redirectToLogin() {
    localStorage.setItem("redirectAfterLogin", window.location.pathname);
    setTimeout(() => {
      window.location.href = "#/login";
    }, 1);
  }
}