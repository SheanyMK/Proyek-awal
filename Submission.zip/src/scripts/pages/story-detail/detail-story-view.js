import L from "leaflet";
import Map from '../../utils/map';
import { showFormattedDate } from "../../utils/index";

import markerIcon2x from 'leaflet/dist/images/marker-icon-2x.png';
import markerIcon from 'leaflet/dist/images/marker-icon.png';
import markerShadow from 'leaflet/dist/images/marker-shadow.png';

delete L.Icon.Default.prototype._getIconUrl;

L.Icon.Default.mergeOptions({
  iconRetinaUrl: markerIcon2x,
  iconUrl: markerIcon,
  shadowUrl: markerShadow,
});

export default class DetailView {
  constructor() {
    this._detailContainer = document.getElementById("detail-container");
    this._mapContainer = document.getElementById("map");
  }

  async showStoryDetail(story) {
    if (document.startViewTransition) {
      await document.startViewTransition(() => this._renderStoryDetail(story));
    } else {
      this._renderStoryDetail(story);
    }
  }

  async _renderStoryDetail(story) {
    let locationName = "Lokasi tidak tersedia";
    if (story.lat && story.lon) {
      try {
        locationName = await Map.getPlaceNameByCoordinate(story.lat, story.lon);
      } catch (error) {
        console.error("Gagal mendapatkan nama lokasi:", error);
        locationName = `${story.lat}, ${story.lon}`;
      }
    }

    this._detailContainer.innerHTML = `
      <div class="story-detail-container">
        <div class="story-image-container">
          <img class="story-image" src="${story.photoUrl}" alt="${story.name}">
        </div>
        
        <div class="story-content">
          <h2 class="story-title">${story.name}</h2>
          
          <div class="story-meta">
            <span class="story-date">
              <i class="fas fa-calendar-alt"></i>
              ${showFormattedDate(new Date(story.createdAt).toLocaleDateString())}
            </span>
            
            ${story.lat && story.lon ? `
            <span class="story-location">
              <i class="fas fa-map-marker-alt"></i>
              ${locationName}
            </span>
            ` : ''}
          </div>
          
          <div class="story-description">
            <p>${story.description}</p>
          </div>
          
          <div class="story-actions">
            <a href="/#/" class="btn-back">
              <i class="fas fa-arrow-left"></i> Kembali ke Beranda
            </a>
          </div>
          <br>
        </div>
      </div>
    `;
  }

  showMapWithMarker(story) {
    if (this._map) {
      this._map.remove();
      this._map = null;
    }

    this._mapContainer.innerHTML = "";
    
    if (story.lat && story.lon) {
      const map = L.map(this._mapContainer).setView([story.lat, story.lon], 15);
      
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: "© OpenStreetMap contributors",
      }).addTo(map);

      const marker = L.marker([story.lat, story.lon]).addTo(map);
      marker.bindPopup(`
        <div class="map-popup">
          <strong>${story.name}</strong><br>
          <p>${story.description}</p>
        </div>
      `);
      
      this._map = map;
    } else {
      this._mapContainer.innerHTML = `
        <div class="no-location">
          <i class="fas fa-map-marked-alt"></i>
          <p>Lokasi tidak tersedia</p>
        </div>
      `;
    }
  }

  showMessage(msg) {
    this._detailContainer.innerHTML = `
      <div class="error-message">
        <i class="fas fa-exclamation-circle"></i>
        <p>${msg}</p>
      </div>
    `;
  }
}