import HomePage from '../pages/home/home-page';
import AboutPage from '../pages/about/about-page';
import RegisterPage from '../pages/auth/register/register-page';
import LoginPage from '../pages/auth/login/login-page';
import AddDataPage from '../pages/add-data/add-page';
import LogoutPage from '../pages/auth/logout/logout-page';
import DetailStoryPage from '../pages/story-detail/detail-story-page';

const routes = {
  '/': new HomePage(),
  '/about': new AboutPage(),
  '/register' : new RegisterPage(),
  '/login' : new LoginPage(),
  '/logout' : new LogoutPage(),
  '/add-data' : new AddDataPage(),
  '/detail/:id': new DetailStoryPage(),
};

export default routes;