export default class Camera {
    #currentStream;
    #streaming = false;
    #width = 640;
    #height = 0;
  
    #videoElement;
    #canvasElement;
    #selectCameraElement;
    #takePictureButton;
  
    constructor({ video, canvas, cameraSelect = null }) {
      this.#videoElement = video;
      this.#canvasElement = canvas;
      this.#selectCameraElement = cameraSelect;
  
      this.#initializeVideoListener();
      if (this.#selectCameraElement) {
        this.#selectCameraElement.onchange = async () => {
          await this.stop();
          await this.launch();
        };
      }
    }
  
    #initializeVideoListener() {
      this.#videoElement.oncanplay = () => {
        if (this.#streaming) return;
  
        this.#height = (this.#videoElement.videoHeight * this.#width) / this.#videoElement.videoWidth;
        this.#canvasElement.width = this.#width;
        this.#canvasElement.height = this.#height;
  
        this.#streaming = true;
      };
    }
  
    static addNewStream(stream) {
        if (!Array.isArray(window.currentStreams)) {
            window.currentStreams = [stream];
            return;
        }
        window.currentStreams = [...(window.currentStreams || []), stream];
    }
  
    static stopAllStreams() {
      (window.currentStreams || []).forEach((stream) => {
        if (stream.active) {
          stream.getTracks().forEach((track) => track.stop());
        }
      });
      window.currentStreams = [];
    }
  
    async #populateCameraOptions(stream) {
      if (!stream) return;
  
      const devices = await navigator.mediaDevices.enumerateDevices();
      const videoDevices = devices.filter((device) => device.kind === 'videoinput');
      const currentId = stream.getVideoTracks()[0]?.getSettings()?.deviceId;
  
      this.#selectCameraElement.innerHTML = videoDevices.map((device, idx) => `
        <option value="${device.deviceId}" ${device.deviceId === currentId ? 'selected' : ''}>
          ${device.label || `Camera ${idx + 1}`}
        </option>
      `).join('');
    }
  
    async #getMediaStream() {
      const constraints = {
        video: {
          aspectRatio: 4 / 3,
        },
      };
  
      if (this.#selectCameraElement && this.#selectCameraElement.value) {
        constraints.video.deviceId = { exact: this.#selectCameraElement.value };
      }
  
      try {
        const stream = await navigator.mediaDevices.getUserMedia(constraints);
        if (this.#selectCameraElement) {
          await this.#populateCameraOptions(stream);
        }
        return stream;
      } catch (err) {
        console.error('Camera access error:', err);
        return null;
      }
    }
  
    async launch() {
      this.#currentStream = await this.#getMediaStream();
      if (!this.#currentStream) return;
  
      Camera.addNewStream(this.#currentStream);
      this.#videoElement.srcObject = this.#currentStream;
      this.#videoElement.play();
  
      this.#clearCanvas();
    }
  
    stop() {
      if (this.#videoElement) {
        this.#videoElement.srcObject = null;
      }
  
      if (this.#currentStream) {
        this.#currentStream.getTracks().forEach((track) => track.stop());
      }
  
      this.#streaming = false;
      this.#clearCanvas();
    }
  
    #clearCanvas() {
      const ctx = this.#canvasElement.getContext('2d');
      ctx.fillStyle = '#CCCCCC';
      ctx.fillRect(0, 0, this.#canvasElement.width, this.#canvasElement.height);
    }
  
    async takePicture() {
      if (!this.#streaming) return null;
  
      const ctx = this.#canvasElement.getContext('2d');
      ctx.drawImage(this.#videoElement, 0, 0, this.#width, this.#height);
  
      return new Promise((resolve) => {
        this.#canvasElement.toBlob((blob) => resolve(blob), 'image/png');
      });
    }
  
    addCheeseButtonListener(selector, callback) {
      this.#takePictureButton = document.querySelector(selector);
      if (this.#takePictureButton) {
        this.#takePictureButton.onclick = callback;
      }
    }
  }  