export default class NavManager {
  constructor() {
    this.navList = document.getElementById("nav-list");
    this.navItems = {
      home: this.navList.querySelector('li a[href="#/"]')?.parentElement,
      about: this.navList.querySelector('li a[href="#/about"]')?.parentElement,
      addData: this.navList.querySelector('li a[href="#/add-data"]')
        ?.parentElement,

      login: this.navList.querySelector('li a[href="#/login"]')?.parentElement,
      register: this.navList.querySelector('li a[href="#/register"]')
        ?.parentElement,
      logout: this.navList.querySelector('li a[href="#/logout"]')
        ?.parentElement,
    };
  }

  updateNavigation() {
    const isLoggedIn = !!localStorage.getItem("accessToken");

    if (this.navItems.login) {
      this.navItems.login.style.display = isLoggedIn ? "none" : "block";
    }

    if (this.navItems.register) {
      this.navItems.register.style.display = isLoggedIn ? "none" : "block";
    }

    if (this.navItems.logout) {
      this.navItems.logout.style.display = isLoggedIn ? "block" : "none";
    }

    if (this.navItems.home) {
      this.navItems.home.style.display = isLoggedIn ? "block" : "none";
    }
    if (this.navItems.about) {
      this.navItems.about.style.display = isLoggedIn ? "block" : "none";
    }
    if (this.navItems.addData) {
      this.navItems.addData.style.display = isLoggedIn ? "block" : "none";
    }
  }
}
